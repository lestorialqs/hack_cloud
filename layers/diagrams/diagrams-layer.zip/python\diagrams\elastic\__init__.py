"""
Elastic provides a set of general elastic services.
"""

from diagrams import Node


class _Elastic(Node):
    _provider = "elastic"
    _icon_dir = "resources/elastic"

    fontcolor = "#ffffff"


class Elastic(_Elastic):
    _icon = "elastic.png"
